 const mongoose= require('mongoose');

 var Employee= mongoose.model('Employee',{
 firstname:{type : String},
 lastname:{type:String},
  email:{type:String},
  password:{type:String},
  gender:{type:String},
  DOB:{type:Date}



 })

 module.exports={Employee};