import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

readonly baseUrl='http://localhost:3000/employees/login';
  constructor(private http: HttpClient) { }

postEmployee(form : FormData){

return this.http.post(this.baseUrl,form);

}

}
