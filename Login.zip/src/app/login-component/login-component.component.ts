import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule,
  FormsModule,
  FormGroup,
  NgForm,
  FormControl,
  Validators,
  FormBuilder } from '@angular/forms';
import {LoginService} from './login.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material'; 

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css'],
   providers: [LoginService]
})
export class LoginComponentComponent implements OnInit {
 
myform: FormGroup;
email:FormControl;
password:FormControl;

  constructor(private loginService :LoginService,private router: Router,public snackbar: MatSnackBar) {
    

    
   }

   ngOnInit() {
    this.createFormControls();
     this.createForm();
  }
  createFormControls() {
  
    this.email = new FormControl("", [
      Validators.required,
      Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')
      
    ]);
    this.password = new FormControl("", [
      Validators.minLength(8),
      Validators.required
      
    ]);
    }
  
    createForm() {
    this.myform = new FormGroup({
     
      Email: this.email,
      Password: this.password,

    });
  }

  account_validation_messages = {

'email': [
  { type: 'required', message: 'Email is required' },
  { type: 'pattern', message: 'Enter a valid email' }
],
'password': [
  { type: 'required', message: 'Password is required' },
  { type: 'minlength', message: 'Password must be at least 8 characters long' },

],
     }





    onSubmit(form:FormGroup) {
    //   var email:string[]=new  Array("saivarma@gmail.com","vinuprakash@gmail.com");
    //   var password:string[]= new Array("saivarma","vinuprakash");
    //  var count:number=0;
    //  var count1:number=0;
    //   if(this.myform.valid){
    //      for(var i=0;i<email.length;i++){
    //   if(this.myform.get("Email").value==email[i] && this.myform.get("Password").value==password[i] ){
    //     alert("login succesful "+this.myform.get("Email").value);
    //   }
    //     else if(this.myform.get("Email").value!=email[i] ){
  
    //  count++;
    // }
    //   else if(this.myform.get("Email").value==email[i] &&this.myform.get("Password").value!=password[i]){
      
    //   count1++;
    // }
    //   }
    // }
    // if(count==email.length){
    //   alert("Incorrect  email, please enter valid email");
    // }
    // if(count1==1) {
    //     alert("Incorrect  password, please enter valid password");
    // }
  

  if(this.myform.valid){
  console.log("Form value====>",form.value);

  this.loginService.postEmployee(form.value).subscribe((res)=>{
  if(res!=null){
  console.log("Login Succesful")
  this.snackbar.open("Login successfull ",'',{duration: 2000,
      verticalPosition: 'bottom'
    });
  }
  else{
    console.log("Login Unsuccesful")
     this.snackbar.open("Login Unsuccessfull ",'',{duration: 2000,
      verticalPosition: 'bottom'
    });
  }
  });
 }
  }

  
}