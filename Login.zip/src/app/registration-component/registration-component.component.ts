import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule,
  FormsModule,
  NgForm,
  FormGroup,
  FormControl,
  Validators,
  FormBuilder } from '@angular/forms';
import {EmployeeService} from './employee.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material'; 

@Component({
  selector: 'app-registration-component',
  templateUrl: './registration-component.component.html',
  styleUrls: ['./registration-component.component.css'],
  providers: [EmployeeService]
})
export class RegistrationComponentComponent implements OnInit {
myform: FormGroup;
firstname:FormControl;
lastname:FormControl;
email:FormControl;
reentered_email:FormControl;
password:FormControl;
gender:FormControl;
date:FormControl;




  constructor(private employeeService :EmployeeService,private router: Router,public snackbar: MatSnackBar) { }

  ngOnInit() {
     this.createFormControls();
     this.createForm();
     
  }

createFormControls() {
  
    this.firstname=new FormControl("",[
      Validators.required,
    ]);
    this.lastname=new FormControl("",[
      Validators.required,
    ]);
 
    this.email = new FormControl("", [
      Validators.required,
      Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z-]{2,}[.]{1}[a-zA-Z]{2,}')
      
    ]);

       this.reentered_email=new FormControl("",[
      Validators.required,
      Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z-]{2,}[.]{1}[a-zA-Z]{2,}')]);


    this.password = new FormControl("", [
      Validators.minLength(8),
      Validators.required
      
    ]);

this.gender=new FormControl("", [
      Validators.required
      
    ]);

    this.date=new FormControl("", [
      Validators.required
      
    ]);


    }
  
    createForm() {
    this.myform = new FormGroup({
     
    
      firstname:this.firstname,
      lastname:this.lastname,
      email: this.email,
      reemail:this.reentered_email,
      password: this.password,
      gender:this.gender,
      date:this.date
    });
  }
  account_validation_messages = {
'firstname': [
  { type: 'required', message: 'firstname is required' },
 
],
'lastname': [
  { type: 'required', message: 'lastname is required' }
  
],
'email': [
  { type: 'required', message: 'Email is required' },
  { type: 'pattern', message: 'Enter a valid email' }
],
'password': [
  { type: 'required', message: 'Password is required' },
  { type: 'minlength', message: 'Password must be at least 8 characters long' },

],
'gender': [
  { type: 'required', message: 'gender is required' }

],
'date': [
  { type: 'required', message: 'date is required' }
],
     }

  register(){
if(this.myform.valid){
    if(this.myform.get("email").value!=this.myform.get("reemail").value){
      alert("Email and re-enterd Email is not matching, please enter properly");
    }
  }
}
onSubmit(form :FormGroup){
  if(this.myform.valid){
  if(this.myform.get("email").value==this.myform.get("reemail").value){
  console.log("form value===>",form.value);
  this.employeeService.postEmployee(form.value).subscribe((res)=>{
    
  if(res==null){
    console.log("Registration Succesful");
    this.snackbar.open("Registration successfull  "+form.value.firstname,'',{duration: 2000,
      verticalPosition: 'bottom'
    });
  //  this.router.navigate(['login']);
  }
  else{
    console.log("Registration unsuccesful email already exists , please try again with new email");
     this.snackbar.open("Registration unsuccesful email already exists , please try again with new email",'',{duration: 2000,
      verticalPosition: 'bottom'
    });  
}
  });
}
}
}



};