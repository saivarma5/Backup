const express=require('express');
var router=express.Router();
  var mongoose = require('mongoose');

var { Employee } =require('../models/employee');

var  ObjectId=mongoose.Types.ObjectId;
router.post('/login',(req,res)=>{
Employee.find(req.body.Email,(err,data)=>{
if(data!=null){
   console.log(data.values);
}
else{
    console.log('Error in retreving');
}

})
})

router.get('/:id',(req,res)=>{

    if(!ObjectId.isValid(req.params.id))
    return res.status(400).send('No record with given id:${req.params.id}');
    Employee.findById(req.params.id,(err,doc)=>{
if(!err){
    res.send(doc);
}
else{
    console.log('Error in retrieving employee by id');
}
    })
})

router.post('/',(req,res)=>{
    
   var query={email:req.body.email};
  Employee.findOne(query,function(err,data){
      if(data==null){
    var emp=new Employee({
        firstname:req.body.firstname,
        lastname:req.body.lastname,
         email:req.body.email,
           password:req.body.password,
           gender:req.body.gender,
           DOB:req.body.date

    })
    emp.save((err,doc)=>{
        if(!err){
            console.log("Registration succesful");
            res.send(data);
        }
        else{
            console.log('Error in Employee save ');
        }
    });
      }
      else{
          console.log(data.email+" email already exists")
          res.send(data);
      }
  });  
  
// var query = { email: req.body.email };
// Employee.find(query).toArray(function(err,result){
//     if(err){
    
    
//     else{
//    console.log("error")
//     }
// })

})

router.put('/:id',(req,res)=>{
    if(!ObjectId.isValid(req.params.id))
    return res.status(400).send('No record with given id:${req.params.id}');

    var emp={
    firstname:req.body.firstname,
        lastname:req.body.lastname,
         email:req.body.email,
           password:req.body.password,
           gender:req.body.gender,
           DOB:req.body.date
    };
    Employee.findByIdAndUpdate(req.params.id,{$set:emp},{new:true},(err,doc)=>{
  if(!err){
            res.send(doc);
        }
        else{
            console.log('Error in Employee update ');
        }
    })

})

router.delete('/:id',(req,res)=>{
    if(!ObjectId.isValid(req.params.id))
    return res.status(400).send('No record with given id:${req.params.id}');

    Employee.findByIdAndRemove(req.params.id,(err,doc)=>{
  if(!err){
            res.send(doc);
        }
        else{
            console.log('Error in Employee delete ');
        }
    })

})


module.exports=router;